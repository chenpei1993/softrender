class Axis{
    
    static createAxis(){
        let origin = new Vector3(0, 0, 0);
        let xAxis = new Vector3(1, 0, 0);
        let yAxis = new Vector3(0, 1, 0);
        let zAxis = new Vector3(0, 0, 1);
        
    }
}