class Pixel{
    constructor(vector, color){
        this.vector = vector;
        this.color = color;
    }
}